package com.app;

import org.junit.Test;


class ApplicationTests {

	@Test
	void contextLoads() {
	}

}
