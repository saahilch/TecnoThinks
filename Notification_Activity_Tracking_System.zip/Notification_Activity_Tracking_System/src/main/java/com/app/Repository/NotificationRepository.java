package com.app.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entities.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
	// Find all notifications for a specific user
	List<Notification> findByUserId(Long userId);
}
