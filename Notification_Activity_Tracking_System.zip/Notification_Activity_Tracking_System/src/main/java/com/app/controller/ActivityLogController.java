package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.dto.ActivityLogRequestDTO;
import com.app.entities.ActivityLog;
import com.app.service.ActivityLogService;

import java.util.List;

@RestController
@RequestMapping("/api/activity")
public class ActivityLogController {

	@Autowired
	private ActivityLogService activityLogService;

	/* for posting the activity log hit url with the required id 
	 * http://localhost:8080/api/activity?userId=2
	 * 
	 * */
	@PostMapping
	public ResponseEntity<String> logUserActivity(@RequestBody ActivityLogRequestDTO request) {
		try {
			activityLogService.logActivity(request);
			return ResponseEntity.ok("Activity logged successfully.");
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
		}
	}

	/*
	 * get api with id hit url with actual id localhost:8080/api/activity?userId=1
	 */
	@GetMapping
	public ResponseEntity<List<ActivityLog>> getUserActivityLogs(@RequestParam Long userId) {
		List<ActivityLog> activityLogs = activityLogService.getActivityLogsForUser(userId);
		return ResponseEntity.ok(activityLogs);
	}
}
