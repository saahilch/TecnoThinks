package com.app.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.NotificationDTO;
import com.app.entities.Notification;
import com.app.service.NotificationService;

@RestController
@RequestMapping("api/notifications")
public class NotificationController {

	@Autowired
	private NotificationService notificationService;

	/*
	 * localhost:8080/api/notifications?userId=1 hti these url to get notification  with the id
	 */
	@GetMapping
	public ResponseEntity<List<NotificationDTO>> getUserNotification(@RequestParam Long userId) {
		List<Notification> notifications = notificationService.getNotificationsForUser(userId);
		List<NotificationDTO> notificationDTOs = notifications.stream()
				.map(notification -> new NotificationDTO(notification.getId(), notification.getType(),
						notification.getContent(), notification.getIsRead(), notification.getCreatedAt()))
				.collect(Collectors.toList());

		return ResponseEntity.ok(notificationDTOs);
	}

	/* localhost:8080/api/notifications/mark-read?userId=1 */
	@PostMapping("/mark-read")
	public ResponseEntity<String> markNotificationsAsRead(@RequestParam Long userId) {
		notificationService.markNotificationsAsRead(userId);
		return ResponseEntity.ok("Notifications marked as read.");
	}

	
	
	
	
	/*
	 * localhost:8080/api/notifications/add then { "type": "INFO", "content":
	 * "Your profile was updated.", "isRead": false, "createdAt":
	 * "2024-11-09T12:56:58", "user": { "id": 1 } }
	 */
	@PostMapping("/add")
	public ResponseEntity<String> addNotification(@RequestBody Notification notification) {
		notificationService.saveNotification(notification);
		return ResponseEntity.ok("Notification added successfully.");
	}

}
