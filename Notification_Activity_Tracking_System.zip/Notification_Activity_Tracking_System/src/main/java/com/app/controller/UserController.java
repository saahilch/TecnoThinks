package com.app.controller;

import com.app.dto.UserDTO;
import com.app.entities.User;
import com.app.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/users")
public class UserController {

	@Autowired
	private UserService userService;

	/* To Get All the Users from DB jus Hit the url 
	 -> localhost8080/api/users
	  * */
	@GetMapping
	public ResponseEntity<List<UserDTO>> getAllUsers() {
		List<User> users = userService.getAllUsers();
		List<UserDTO> userDTOs = users.stream().map(user -> new UserDTO(user.getId(), user.getEmail(),
				user.getFirstName(), user.getLastName(), user.getCreatedAt(), user.getUpdatedAt()))
				.collect(Collectors.toList());
		return ResponseEntity.ok(userDTOs);
	}

  /* To Get Uers By Id Form  DB Just Hit the url
   -> localhost8080/api/users/1
  
   */
	@GetMapping("/{id}")
	public ResponseEntity<UserDTO> getUserById(@PathVariable Long id) {
		Optional<User> user = userService.getUserById(id);
		if (user.isPresent()) {
			UserDTO userDTO = new UserDTO(user.get().getId(), user.get().getEmail(), user.get().getFirstName(),
					user.get().getLastName(), user.get().getCreatedAt(), user.get().getUpdatedAt());
			return ResponseEntity.ok(userDTO);
		} else {
			return ResponseEntity.notFound().build();
		}
	}
}
