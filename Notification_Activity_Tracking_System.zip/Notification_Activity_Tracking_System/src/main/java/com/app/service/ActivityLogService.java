package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.Repository.ActivityLogRepository;
import com.app.Repository.UserRepository;
import com.app.dto.ActivityLogRequestDTO;
import com.app.entities.ActivityLog;
import com.app.entities.User;

import java.util.List;

@Service
public class ActivityLogService {

	@Autowired
	private ActivityLogRepository activityLogRepository;
	@Autowired
	private UserRepository userRepository;

	public void logActivity(ActivityLogRequestDTO request) {
		User user = userRepository.findById(request.getUserId())
				.orElseThrow(() -> new RuntimeException("User not found"));

		ActivityLog activityLog = new ActivityLog();
		activityLog.setUser(user);
		activityLog.setActivityType(request.getActivityType());
		activityLog.setDescription(request.getDescription());
		activityLog.setIpAddress(request.getIpAddress());

		activityLogRepository.save(activityLog);
	}

	public List<ActivityLog> getActivityLogsForUser(Long userId) {
		return activityLogRepository.findByUserId(userId);
	}
}
