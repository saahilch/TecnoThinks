package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.Repository.NotificationRepository;
import com.app.entities.Notification;

@Service
public class NotificationService {
	
	 @Autowired
	    private NotificationRepository notificationRepository;
	
	 public List<Notification> getNotificationsForUser(Long userId) {
	        return notificationRepository.findByUserId(userId);
	    }

	    public void markNotificationsAsRead(Long userId) {
	        List<Notification> notifications = notificationRepository.findByUserId(userId);
	        notifications.forEach(notification -> notification.setIsRead(true));
	        notificationRepository.saveAll(notifications);
	    }
	    
	    public void saveNotification(Notification notification) {
	        notificationRepository.save(notification); // Save notification to the database
	    }

}
