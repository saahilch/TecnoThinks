package com.app.entities;
//
//import java.time.LocalDateTime;
//import java.util.List;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.OneToMany;
//import javax.persistence.Table;
//
//import com.fasterxml.jackson.annotation.JsonIgnore;
//import com.fasterxml.jackson.annotation.JsonManagedReference;
//
//@Entity
//@Table(name = "users")
//public class User {
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private Long id;
//
//	@Column(unique = true, nullable = false)
//	private String email;
//
//	@Column(nullable = false)
//	private String firstName;
//
//	@Column(nullable = false)
//	private String lastName;
//
//	@Column(nullable = false, updatable = false)
//	private LocalDateTime createdAt = LocalDateTime.now();
//
//	@Column(nullable = false)
//	private LocalDateTime updatedAt = LocalDateTime.now();
//
//	// Ignore notifications to prevent recursion
//	@JsonIgnore
//	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
//	private List<Notification> notifications;
//
//	// Activity logs are not part of the recursion, so you can leave them without
//	// @JsonIgnore
//	@JsonManagedReference
//	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
//	private List<ActivityLog> activityLogs;
//
//	public User(Long id, String email, String firstName, String lastName, LocalDateTime createdAt,
//			LocalDateTime updatedAt, List<Notification> notifications, List<ActivityLog> activityLogs) {
//		super();
//		this.id = id;
//		this.email = email;
//		this.firstName = firstName;
//		this.lastName = lastName;
//		this.createdAt = createdAt;
//		this.updatedAt = updatedAt;
//		this.notifications = notifications;
//		this.activityLogs = activityLogs;
//	}
//
//	public User() {
//		super();
//	}
//
//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}
//
//	public String getEmail() {
//		return email;
//	}
//
//	public void setEmail(String email) {
//		this.email = email;
//	}
//
//	public String getFirstName() {
//		return firstName;
//	}
//
//	public void setFirstName(String firstName) {
//		this.firstName = firstName;
//	}
//
//	public String getLastName() {
//		return lastName;
//	}
//
//	public void setLastName(String lastName) {
//		this.lastName = lastName;
//	}
//
//	public LocalDateTime getCreatedAt() {
//		return createdAt;
//	}
//
//	public void setCreatedAt(LocalDateTime createdAt) {
//		this.createdAt = createdAt;
//	}
//
//	public LocalDateTime getUpdatedAt() {
//		return updatedAt;
//	}
//
//	public void setUpdatedAt(LocalDateTime updatedAt) {
//		this.updatedAt = updatedAt;
//	}
//
//	public List<Notification> getNotifications() {
//		return notifications;
//	}
//
//	public void setNotifications(List<Notification> notifications) {
//		this.notifications = notifications;
//	}
//
//	public List<ActivityLog> getActivityLogs() {
//		return activityLogs;
//	}
//
//	public void setActivityLogs(List<ActivityLog> activityLogs) {
//		this.activityLogs = activityLogs;
//	}
//
//}

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "users")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(unique = true, nullable = false)
	private String email;

	@Column(nullable = false)
	private String firstName;

	@Column(nullable = false)
	private String lastName;

	@Column(nullable = false, updatable = false)
	private LocalDateTime createdAt = LocalDateTime.now();

	@Column(nullable = false)
	private LocalDateTime updatedAt = LocalDateTime.now();

	@JsonManagedReference // Manages the activityLogs serialization here without recursion
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private List<ActivityLog> activityLogs;

	@JsonManagedReference // Manages the notifications serialization here without recursion
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private List<Notification> notifications;

	public User(Long id, String email, String firstName, String lastName, LocalDateTime createdAt,
			LocalDateTime updatedAt, List<ActivityLog> activityLogs, List<Notification> notifications) {
		super();
		this.id = id;
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.activityLogs = activityLogs;
		this.notifications = notifications;
	}

	public User() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<ActivityLog> getActivityLogs() {
		return activityLogs;
	}

	public void setActivityLogs(List<ActivityLog> activityLogs) {
		this.activityLogs = activityLogs;
	}

	public List<Notification> getNotifications() {
		return notifications;
	}

	public void setNotifications(List<Notification> notifications) {
		this.notifications = notifications;
	}

	
}
