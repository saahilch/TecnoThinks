package com.app.entities;
//
//import java.time.LocalDateTime;
//import java.util.List;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
//import javax.persistence.Table;
//
//import com.fasterxml.jackson.annotation.JsonBackReference;
//import com.fasterxml.jackson.annotation.JsonIgnore;
//
//@Entity
//@Table(name = "activity_log")
//public class ActivityLog {
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@JsonBackReference
//	private Long id;
//
//	@JsonBackReference
//	@ManyToOne
//	@JoinColumn(name = "user_id", nullable = false)
//	private User user;
//
//	@Column(nullable = false)
//	private String activityType;
//
//	@Column(nullable = false)
//	private String description;
//
//	@Column(nullable = false, updatable = false)
//	private LocalDateTime timestamp = LocalDateTime.now();
//
//	@Column(nullable = false)
//	private String ipAddress;
//	
//	
//
//
//	public ActivityLog(Long id, User user, String activityType, String description, LocalDateTime timestamp,
//			String ipAddress) {
//		super();
//		this.id = id;
//		this.user = user;
//		this.activityType = activityType;
//		this.description = description;
//		this.timestamp = timestamp;
//		this.ipAddress = ipAddress;
//	}
//
//	public ActivityLog() {
//		super();
//	}
//
//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}
//
//	public User getUser() {
//		return user;
//	}
//
//	public void setUser(User user) {
//		this.user = user;
//	}
//
//	public String getActivityType() {
//		return activityType;
//	}
//
//	public void setActivityType(String activityType) {
//		this.activityType = activityType;
//	}
//
//	public String getDescription() {
//		return description;
//	}
//
//	public void setDescription(String description) {
//		this.description = description;
//	}
//
//	public LocalDateTime getTimestamp() {
//		return timestamp;
//	}
//
//	public void setTimestamp(LocalDateTime timestamp) {
//		this.timestamp = timestamp;
//	}
//
//	public String getIpAddress() {
//		return ipAddress;
//	}
//
//	public void setIpAddress(String ipAddress) {
//		this.ipAddress = ipAddress;
//	}
//
//	@JsonIgnore
//	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
//	private List<ActivityLog> activityLogs;
//
//	
//}


import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "activity_log")
public class ActivityLog {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@JsonBackReference // Prevents recursion by marking the back reference
	@ManyToOne
	@JoinColumn(name = "user_id", nullable = false)
	private User user;

	@Column(nullable = false)
	private String activityType;

	@Column(nullable = false)
	private String description;

	@Column(nullable = false, updatable = false)
	private LocalDateTime timestamp = LocalDateTime.now();

	@Column(nullable = false)
	private String ipAddress;

	
	
	public ActivityLog() {
		super();
	}

	public ActivityLog(Long id, User user, String activityType, String description, LocalDateTime timestamp,
			String ipAddress) {
		super();
		this.id = id;
		this.user = user;
		this.activityType = activityType;
		this.description = description;
		this.timestamp = timestamp;
		this.ipAddress = ipAddress;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getActivityType() {
		return activityType;
	}

	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	
}
