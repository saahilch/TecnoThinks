package com.app.dto;

import java.time.LocalDateTime;

public class NotificationDTO {
	private Long id;
	private String type;
	private String content;
	private Boolean isRead;
	private LocalDateTime createdAt;

	public NotificationDTO(Long id, String type, String content, Boolean isRead, LocalDateTime createdAt) {
		this.id = id;
		this.type = type;
		this.content = content;
		this.isRead = isRead;
		this.createdAt = createdAt;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Boolean getIsRead() {
		return isRead;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

}
